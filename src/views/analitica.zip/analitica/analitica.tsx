import React from "react";
import { Box, Typography, CircularProgress, Button } from "@mui/material";
import { useAuth } from "../../hooks/useAuth"; // Ruta correcta (2 niveles)
import Dashboard from "./dashboard/dashboard";
import { useNavigate } from "react-router-dom";

// --- SIMULACIÓN DE BASE DE DATOS / API ---
// Estos datos viven aquí, o vendrían de una llamada a la API
const datosKPIs = {
  ingresos: 11600,
  pedidos: 86,
  mejorRegion: "Norte",
  porcentajeRegion: 38
};

const tendenciasDb = [
  { mes: "Ene", ventas: 4000, meta: 2400 },
  { mes: "Feb", ventas: 3000, meta: 1398 },
  { mes: "Mar", ventas: 2000, meta: 9800 },
  { mes: "Abr", ventas: 2780, meta: 3908 },
  { mes: "May", ventas: 1890, meta: 4800 },
  { mes: "Jun", ventas: 2390, meta: 3800 },
];

const regionesDb = [
  { name: "Norte", value: 4500 },
  { name: "Sur", value: 3200 },
  { name: "Centro", value: 2100 },
  { name: "Occidente", value: 1800 },
];

const Analitica: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // 1. LÓGICA DE SEGURIDAD
  // Verificamos si el usuario existe y tiene rol
  const esGerenteOAdmin = user && (user.role === "gerente" || user.role === "admin");

  // Caso A: Usuario no autorizado
  if (!esGerenteOAdmin) {
    return (
      <Box 
        sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center', 
          justifyContent: 'center', 
          height: '80vh',
          gap: 2
        }}
      >
         <Typography variant="h4" color="error" sx={{ fontWeight: 'bold' }}>
             Acceso Denegado
         </Typography>
         <Typography variant="body1" color="textSecondary">
            No tienes permisos para ver el módulo de Analítica.
         </Typography>
         <Button variant="contained" onClick={() => navigate('/')}>
            Volver al Inicio
         </Button>
      </Box>
    );
  }

  // Caso B: Usuario Autorizado -> Enviamos los datos al Dashboard
  return (
    <>
      <Dashboard 
        kpis={datosKPIs}
        dataTendencias={tendenciasDb}
        dataRegiones={regionesDb}
      />
    </>
  );
};

export default Analitica;