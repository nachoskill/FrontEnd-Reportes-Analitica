import React from "react";
import { 
  Box, Grid, Paper, Typography, Card, CardContent, 
  Table, TableBody, TableCell, TableContainer, 
  TableHead, TableRow, Divider, Chip 
} from "@mui/material";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, 
  Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend
} from "recharts";

// Definimos qué datos necesita este dashboard para funcionar
interface DashboardProps {
  kpis: {
    ingresos: number;
    pedidos: number;
    mejorRegion: string;
    porcentajeRegion: number;
  };
  dataTendencias: { mes: string; ventas: number; meta: number }[];
  dataRegiones: { name: string; value: number }[];
}

const COLORES_REGIONES = ["#1F4D5D", "#FF8042", "#00C49F", "#FFBB28"];

const Dashboard: React.FC<DashboardProps> = ({ kpis, dataTendencias, dataRegiones }) => {
  
  return (
    <Box sx={{ flexGrow: 1, p: 2 }}>
      
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#1F4D5D' }}>
          Analíticas de Ventas
        </Typography>
        <Typography variant="body1" color="textSecondary">
          Visualización de rendimiento global y regional.
        </Typography>
      </Box>

      {/* --- SECCIÓN DE KPIs (Datos vienen de props) --- */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={4}>
          <Card elevation={3} sx={{ borderRadius: 2 }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom variant="overline">Ingresos Totales</Typography>
              <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                ${kpis.ingresos.toLocaleString()}
              </Typography>
              <Chip label="+5.4%" color="success" size="small" sx={{ mt: 1 }} />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card elevation={3} sx={{ borderRadius: 2 }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom variant="overline">Pedidos Activos</Typography>
              <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                {kpis.pedidos}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                En proceso de envío
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card elevation={3} sx={{ borderRadius: 2 }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom variant="overline">Mejor Región</Typography>
              <Typography variant="h4" sx={{ fontWeight: 'bold' }}>{kpis.mejorRegion}</Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                {kpis.porcentajeRegion}% del volumen total
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* --- GRÁFICOS --- */}
      <Grid container spacing={3}>
        <Grid item xs={12} lg={8}>
          <Paper sx={{ p: 3, height: 450, borderRadius: 2 }} elevation={2}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Tendencia Semestral
            </Typography>
            <Divider sx={{ mb: 3 }} />
            <ResponsiveContainer width="100%" height="85%">
              <BarChart data={dataTendencias}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="mes" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip />
                <Bar dataKey="ventas" fill="#1F4D5D" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} lg={4}>
          <Paper sx={{ p: 3, height: 450, borderRadius: 2 }} elevation={2}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Distribución Regional
            </Typography>
            <Divider sx={{ mb: 3 }} />
            <Box sx={{ height: '85%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={dataRegiones}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {dataRegiones.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORES_REGIONES[index % COLORES_REGIONES.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }} elevation={2}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Detalle Regional
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Región</TableCell>
                    <TableCell align="right">Ventas Totales</TableCell>
                    <TableCell align="right">Estado</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {dataRegiones.map((row) => (
                    <TableRow key={row.name} hover>
                      <TableCell component="th" scope="row">{row.name}</TableCell>
                      <TableCell align="right">${row.value}</TableCell>
                      <TableCell align="right">
                         <Chip label="Activo" color="success" size="small" variant="outlined"/>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;